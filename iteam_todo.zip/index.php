<title>SpedToDo</title>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="style/custom-theme/jquery-ui-1.8.21.custom.css">
<link rel="stylesheet" type="text/css" href="style/css.css">
<script type="text/javascript" src="js/jquery-1.7.2.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.21.custom.min.js"></script>
<script type="text/javascript" src="js/jquery.ddslick.js"></script>

<script type="text/javascript" src="start.js"></script>

<?php
	include("mysql.php");
?>

<div id="header" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
<h1>STD-Test  JQuery JQueryUI</h1>
</div>
<input type="text" id="UserID" value="<?php echo @$_COOKIE['UserID']; ?>">
<input type="text" id="AufgabeID" value="<?php echo @$_COOKIE['AufgabeID']; ?>">
<input type="text" id="AfgFilter" value="<?php echo @$_COOKIE['AfgFilter']; ?>" OnChange="ToDosAktl();">
<br>
<table>
	<tr>
		<td width="230">
			<div id="user" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
				
			</div>
		</td>
		<td width="400">
			<div id="liste" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
			
			</div>
		</td>
		<td>
			<div id="aufgabe" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
			
			</div>
		</td>
	</tr>
</table>
<div id="hidden" style="visibility:hidden;"></div>