-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 14. Mai 2013 um 10:12
-- Server Version: 5.5.25a
-- PHP-Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `iteam_aufgaben`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_aufgaben`
--

CREATE TABLE IF NOT EXISTS `tbl_aufgaben` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datum_eingestellt` int(13) NOT NULL,
  `bearbeiter` text NOT NULL,
  `aufgabensteller` text NOT NULL,
  `header` text NOT NULL,
  `datum_erledigt` int(13) DEFAULT NULL,
  `text` mediumtext NOT NULL,
  `status` text NOT NULL,
  `datum_sp_fertig` int(13) NOT NULL,
  `datum_gepl_fertig` int(13) NOT NULL,
  `Kunde` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `tbl_aufgaben`
--

INSERT INTO `tbl_aufgaben` (`id`, `datum_eingestellt`, `bearbeiter`, `aufgabensteller`, `header`, `datum_erledigt`, `text`, `status`, `datum_sp_fertig`, `datum_gepl_fertig`, `Kunde`) VALUES
(1, 1355303948, '7', '19', 'Test', NULL, '', 'Bearbeitung', 0, 0, '6');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `pw` varchar(1) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Daten für Tabelle `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `pw`, `name`) VALUES
(4, 'krenz', 'e', 'Krenz, Fabian'),
(6, 'schlosser', '9', 'Schlosser, Christian'),
(7, 'kaufmann', 'f', 'Kaufmann, Sascha'),
(19, 'gersthahn', '3', 'Gersthahn, Andreas'),
(15, 'wildey', 'c', 'Wildey, Michael'),
(16, 'hoffmann', 'b', 'Hoffmann, Philipp');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
