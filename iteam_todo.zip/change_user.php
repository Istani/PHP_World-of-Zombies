<?php
	include("mysql.php");
	//var_dump($_GET);
	
	$sql['change']="UPDATE tbl_aufgaben SET bearbeiter='".$_GET['id']."' WHERE id='".$_GET['afg']."'";
	mysql_query($sql['change']);
?>